<?php
include_once("db_connection.php");
include_once("functions.php");
function Nevek2() {
    $con = ConnectDB();
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $nev = $_POST["nev"];
        $sql = "
        select
            vevo.vnev,
            rendeles.idopont,
            pizza.pnev,
            pizza.par,
            tetel.db,
            (pizza.par * tetel.db) as 'Osszesen'
        from rendeles
            left join vevo on rendeles.vazon = vevo.vazon
            left join tetel on rendeles.razon = tetel.razon
            left join pizza on tetel.pazon = pizza.pazon
        where vevo.vnev = '$nev'
        order by vevo.vnev, rendeles.idopont;";
        $result = $con->query($sql); // eredmenyhalmaz
        $output = "";
        if($result->num_rows > 0){
            while($row = $result->fetch_assoc()){
                $output .= "<tr>";
                $output .= "<td>" . $row["vnev"] . "</td>";
                $output .= "<td>" . $row["idopont"] . "</td>";
                $output .= "<td>" . $row["pnev"] . "</td>";
                $output .= "<td>" . $row["par"] . "</td>";
                $output .= "<td>" . $row["db"] . "</td>";
                $output .= "<td>" . $row["Osszesen"] . "</td>";
                $output .= "</tr>";
            }
        }
        else{
            echo "A lekerdezes nem adott vissza egy sort sem!";
        }
        return $output;
    }
    DisconnectDB();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>PHP es MySQL osszekapcsolasa</title>
    <meta charset="utf-8">
    <link rel="stylesheet" href="style.css">
</head>
<body>
<h1>Eddigi rendelesek</h1>
<h2>Szures:</h2>
<form action='nevek.php' method='post'>
    <label for='nev'>Nev:</label>
    <select id='nev' name='nev'">
    <?php echo Nevek(); ?>
    </select>
    <input type='submit' value='Szures'>
</form>
<br>
<table>
    <thead>
    <tr>
        <th>Vevo neve</th>
        <th>Vasarlas idopontja</th>
        <th>Pizza</th>
        <th>Pizza ar (/db)</th>
        <th>Mennyiseg (db)</th>
        <th>Osszeg (HUF)</th>
    </tr>
    </thead>
    <tbody>
    <?php echo Nevek2(); ?>
    </tbody>
</table>
</body>
</html>
