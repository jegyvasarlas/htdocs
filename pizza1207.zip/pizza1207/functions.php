<?php
include_once("db_connection.php");
function Rendelesek() {
    $con = ConnectDB();
    $sql = "
    select
        vevo.vnev,
        rendeles.idopont,
        pizza.pnev,
        pizza.par,
        tetel.db,
        (pizza.par * tetel.db) as 'Osszesen'
    from rendeles
        left join vevo on rendeles.vazon = vevo.vazon
        left join tetel on rendeles.razon = tetel.razon
        left join pizza on tetel.pazon = pizza.pazon
    order by vevo.vnev, rendeles.idopont;";
    $result = $con->query($sql); // eredmenyhalmaz
    $output = "";
    if($result->num_rows > 0){
        while($row = $result->fetch_assoc()){
            $output .= "<tr>";
            $output .= "<td>" . $row["vnev"] . "</td>";
            $output .= "<td>" . $row["idopont"] . "</td>";
            $output .= "<td>" . $row["pnev"] . "</td>";
            $output .= "<td>" . $row["par"] . "</td>";
            $output .= "<td>" . $row["db"] . "</td>";
            $output .= "<td>" . $row["Osszesen"] . "</td>";
            $output .= "</tr>";
        }
    }
    else{
        echo "A lekerdezes nem adott vissza egy sort sem!";
    }
    return $output;
    DisconnectDB($con);
}
function Nevek()
{
    $con = ConnectDB();
    $sql = "select vevo.vnev from vevo order by vnev;";
    $result = $con->query($sql); // eredmenyhalmaz
    $output = "";
    if($result->num_rows > 0){
        while($row = $result->fetch_assoc()){
            $output .= "<option value='none' selected disabled hidden>&nbsp</option>";
            $output .= "<option value='" . $row["vnev"] . "'>" . $row["vnev"] . "</option>";
        }
    }
    else{
        echo "A lekerdezes nem adott vissza egy sort sem!";
    }
    return $output;
    DisconnectDB($con);
}

?>
