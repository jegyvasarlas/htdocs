<?php
function ConnectDB(){
    $server = "localhost";
    $user = "root";
    $psw = "";
    $db = "pizza";

    // Create connection
    $con = new mysqli($server, $user, $psw, $db);

    // !!!! Sikerult-e csatlakozni az adatbazishoz
    if($con->connect_error){
        die("Connection failed: " . $con->connect_error);
    }

    $con->set_charset("utf8");
    return $con;
}

function DisconnectDB(&$con){
    $con->close();
}
?>
